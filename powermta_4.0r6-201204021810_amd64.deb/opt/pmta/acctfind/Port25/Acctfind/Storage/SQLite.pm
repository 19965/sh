#!/usr/bin/perl -w
#
# Storage module for Acctfind.pm based on DBD::SQLite
#
use strict;

package Port25::Acctfind::Storage::SQLite;

use vars qw(@ISA);

@ISA = ("Port25::Acctfind::Storage");


# not using "use" to prevent rpm from automatically creating a dependecy :-(
BEGIN { require DBI; DBI->import();    require DBD::SQLite; DBD::SQLite->import();  };

sub new {
    my $class = shift @_;
    my $tmpDir = shift @_;
    
    my $self = $class->SUPER::new($tmpDir);
    
    $self->{acctfind} = shift @_;
    
    my $dbh = DBI->connect("dbi:SQLite:dbname=$self->{dbFile}","","")
        or die $DBI::errstr;;
        
    $self->{dbh} = $dbh;
    
    $dbh->do("create table acctfind (key blob primary key asc, value blob)")
        or die $dbh->errstr;
        
    my $getSth = $dbh->prepare("select value, key from acctfind order by key asc")
        or die $dbh->errstr;
    my $putSth = $dbh->prepare("insert into acctfind (key, value) values (?, ?)")
        or die $dbh->errstr;
        
    $self->{getSth} = $getSth;
    $self->{putSth} = $putSth;
    
    $self->{dbEntries} = 0;
    $self->{dbEntryCounter} = "a" x 8, # About 8 billion
    
    return $self;
}


sub DESTROY {
    my $self = shift @_;
    
    $self->{getSth}->finish() if $self->{getSth};
    $self->{putSth}->finish() if $self->{putSth};
    delete $self->{getSth};
    delete $self->{putSth};
    $self->{dbh}->disconnect() if $self->{dbh};
    delete $self->{dbh};
    
    undef $self->{db};
    untie $self->{records};
#    $self->unlinkDbFile();
    
    $self->SUPER::DESTROY(@_);
}


sub setupSorting {
    my $self = shift @_;
    
    $self->{sortByDomain} = shift @_;
    $self->{sortingTag} = shift @_;
    $self->{sortingHeader} = shift @_;
}


# retrieve matched record from DB file and return pointer to its hash or
# status code on failure
sub loadRecord {
    my $self = shift @_;
    my $key = shift @_;
    my $n = shift @_;
    
    if ($n == 0) {
        $self->{getSth}->execute() or die $self->{getSth}->errstr();
    }
    
    my $row;
    unless ($row = $self->{getSth}->fetchrow_arrayref()) {
        die $self->{getSth}->errstr() if $self->{getSth}->errstr();
        return undef, undef, undef; # end of db
    }
    
    my $chunk = $row->[0];
    
    my $rec = $self->{acctfind}->thawRec($chunk) if $chunk;# and $status == 0;
    
    return 0, $key, $rec;
}


# generates a (unique) key for sorting the records
#
# @param   $rec      a reference to the record to generate the key for
# @return  the generated key
sub generateSortingKeyForRec {
    my $self = shift @_;
    my $rec  = shift @_;
    
    my $key;
    
    if ($self->{sortingTag} eq "internal:header") {
        my $headers = $$rec{"record." . $self->{acctfind}->getTag("header")};
        foreach my $header (@$headers) {
            if ($$header{name} eq $self->{sortingHeader}) {
                $key = $$header{content};
                last;
            }
        }
    }
    else {
        $key = $$rec{$self->{sortingTag}};
    }
    
    if ($key) {
        $key =~ s/.*@/@/ if $self->{sortByDomain};
    }
    else {
        $key = " ";
    }
    
    $key .= "\0$self->{dbEntryCounter}"; # make the keys unique and the sorting stable
    
    return $key;
}



sub storeRecord {
    my $self = shift @_;
    my $rec = shift @_;
    
    my $status;
    my $key;
    
    $self->{dbEntryCounter}++;
    $key = lc $self->generateSortingKeyForRec($rec);
    
    my $chunk = $self->{acctfind}->freezeRec($rec);
    
    $self->{putSth}->execute($key, $chunk)
        or die $self->{putSth}->errstr();
        
    # add frozen record to DB_File
    # downcase keys to make sorting case independent
#    $status = $db->put(lc $key, $chunk);
    
#    if ($status and $self->{acctfind}->{options}{verbose}) {
#        use Data::Dumper;
#        print STDERR "error '$status' while writing $self->{dbFile}: '$!'\n";
##        print STDERR "$recordCounter records read\n";
#        print STDERR "key=$key\n";
#        print STDERR Dumper($rec);
##        $doStop = 1;
#        # abexit "error $status while writing $self->{dbFile}: $!",
#        # $self->{options}{verbose};
#    }
    
    $self->{dbEntries}++;
    
    return undef;
}


1;

