#!/usr/bin/perl -w
#
# Storage module for Acctfind.pm based on DB_File
#
use strict;

package Port25::Acctfind::Storage::DBFile;

use vars qw(@ISA);

@ISA = ("Port25::Acctfind::Storage");


# not using "use" to prevent rpm from automatically creating a dependecy :-(
BEGIN { require DB_File; DB_File->import(); };


sub new {
    my $class = shift @_;
    my $tmpDir = shift @_;
    
    my $self = $class->SUPER::new($tmpDir);
    
    $self->{acctfind} = shift @_;
    
    my %records;
    $self->{db} = tie %records, "DB_File", "$self->{dbFile}",
                                O_RDWR|O_CREAT, 0666, $DB_BTREE
        or die "$0: could not open DB file $self->{dbFile}: $!\n";
        
    $self->{records} = %records;
    
    $self->{dbEntries} = 0;
    $self->{dbEntryCounter} = "a" x 8, # About 8 billion
    
    return $self;
}


sub DESTROY {
    my $self = shift @_;
    
    undef $self->{db};
    untie $self->{records};
#    $self->unlinkDbFile();
    
    $self->SUPER::DESTROY(@_);
}


sub setupSorting {
    my $self = shift @_;
    
    $self->{sortByDomain} = shift @_;
    $self->{sortingTag} = shift @_;
    $self->{sortingHeader} = shift @_;
}


# retrieve matched record from DB file and return pointer to its hash or
# status code on failure
sub loadRecord {
    my $self = shift @_;
    my $key = shift @_;
    my $n = shift @_;
    
    my $r_cursor = ($n == 0) ? R_FIRST : R_NEXT;
    
    # retrieve frozen record from DB_File
    my $chunk = '';
    my $status = $self->{db}->seq($key, $chunk, $r_cursor);
    if ($status != 0) {
        # warn or maybe throw exception
    }
    
    my $rec = $self->{acctfind}->thawRec($chunk) if $chunk and $status == 0;
    
    return $status, $key, $rec;
}


# generates a (unique) key for sorting the records
#
# @param   $rec      a reference to the record to generate the key for
# @return  the generated key
sub generateSortingKeyForRec {
    my $self = shift @_;
    my $rec  = shift @_;
    
    my $key;
    
    if ($self->{sortingTag} eq "internal:header") {
        my $headers = $$rec{"record." . $self->{acctfind}->getTag("header")};
        foreach my $header (@$headers) {
            if ($$header{name} eq $self->{sortingHeader}) {
                $key = $$header{content};
                last;
            }
        }
    }
    else {
        $key = $$rec{$self->{sortingTag}};
    }
    
    if ($key) {
        $key =~ s/.*@/@/ if $self->{sortByDomain};
    }
    else {
        $key = " ";
    }
    
    $key .= "\0$self->{dbEntryCounter}";
    
    return $key;
}



sub storeRecord {
    my $self = shift @_;
    my $rec = shift @_;
    
    my $db = $self->{db};
    my $status;
    my $key;
    
    $self->{dbEntryCounter}++;
    $key = $self->generateSortingKeyForRec($rec);
    
    my $chunk = $self->{acctfind}->freezeRec($rec);
    
    # add frozen record to DB_File
    # downcase keys to make sorting case independent
    $status = $db->put(lc $key, $chunk);
    
#    if ($status and $self->{acctfind}->{options}{verbose}) {
#        use Data::Dumper;
#        print STDERR "error '$status' while writing $self->{dbFile}: '$!'\n";
##        print STDERR "$recordCounter records read\n";
#        print STDERR "key=$key\n";
#        print STDERR Dumper($rec);
##        $doStop = 1;
#        # abexit "error $status while writing $self->{dbFile}: $!",
#        # $self->{options}{verbose};
#    }
    
    $self->{dbEntries}++;
    
    return $status != 0 ? $! : undef;
}


1;

