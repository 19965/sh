#!/usr/bin/perl -w
#
# Super class of the storage modules for Acctfind.pm
#
use strict;

package Port25::Acctfind::Storage;

use File::Temp qw/:mktemp/;
use Cwd;


sub new {
    my $class = shift @_;
    my $tmpDir = shift @_;
    $tmpDir = "." unless $tmpDir;
    $tmpDir = "/tmp" if $tmpDir eq "/";
    
    my $self = bless {}, $class;
    
    my $dirSep = ($^O eq 'MSWin32') ? "\\" : "/";
    my $quotedDirSep = $dirSep;
    $quotedDirSep =~ s/\\/\\\\/g;
    
    $tmpDir .= $dirSep unless $tmpDir =~ /$quotedDirSep$/;
    
    $self->{tmpDir} = $tmpDir;
    
    $self->createDbFileName();
    
    return $self;
}


sub DESTROY {
    my $self = shift@_;
    
    unlink $self->{dbFile} if $self->{dbFile};
    delete $self->{dbFile};
}


sub dbFile {
    my $self = shift @_;
    
    return $self->{dbFile};
}


# Creates a name for a file that does not exist in the temporary directory
sub createDbFileName {
    my $self = shift @_;
     
    return if $self->{dbFile};
    
    my $dbFile;
    
    do {
        $dbFile = mktemp("$self->{tmpDir}acctfind-XXXXX");
    }
    while (-f $dbFile);
    
    $self->{dbFile} = $dbFile;
}


sub rewindDb {
}


1;

